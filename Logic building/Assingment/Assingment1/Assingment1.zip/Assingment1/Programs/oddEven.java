public class oddEven {
     public static void main(String[] args) {
      int num = 8;
 
     if (num % 2 == 0) {
         System.out.println("Num is even"); 
} else {  System.out.println("Num is odd");
}
}
     
}
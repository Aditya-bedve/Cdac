public class goodMorning {
     public static void main(String[] args) {
      int time = 6;
 
     if (time > 5 && time < 12) {
         System.out.println("Good Morning"); 
} else {  System.out.println("It is not morning");
}
}
     
}
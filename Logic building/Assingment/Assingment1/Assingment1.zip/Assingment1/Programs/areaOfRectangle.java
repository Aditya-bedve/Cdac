public class areaOfRectangle {
     public static void main(String[] args) {
      int length = 8;
      int width = 12; 
      int area = length * width;
      System.out.println("Area of rectangle is" + area);

}
     
}
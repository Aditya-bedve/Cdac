public class negativeNumber {
    public static void main(String[] args) {
     int num = -9;

    if (num < 0) {
        System.out.println("num is negative"); 
} else {  System.out.println("num is not negative");
}
}
    
}
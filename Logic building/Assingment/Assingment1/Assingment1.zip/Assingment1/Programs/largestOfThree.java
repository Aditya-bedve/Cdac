public class largestOfThree {
     public static void main(String[] args) {
      int num1 = 8;
      int num2 = 12;
      int num3 = 15;
      
      if (num1 > num2){
      System.out.println("num 1 is greatest");
} else {
      System.out.println("num2 is greatest");
}
     if (num2 > num3) {
      System.out.println("num 2 is greatest");
}  else { 
     System.out.println("num 3 is greatest");
}

}
     
}
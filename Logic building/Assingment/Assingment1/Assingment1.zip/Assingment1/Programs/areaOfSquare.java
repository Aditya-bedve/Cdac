public class areaOfSquare {
     public static void main(String[] args) {
      int side1 = 4;
      int side2 = 4; 
      int area = side1 * side2;
      System.out.println("Area of square is" + area);

}
     
}
    
public class positiveNumber {
     public static void main(String[] args) {
      int num = 5;
 
     if (num > 0) {
         System.out.println("Num is Positive"); 
} else {  System.out.println("Num is not postive");
}
}
     
}